from pathlib import Path
from piper import PiperVoice
from piper.download import ensure_voice_exists, find_voice, get_voices


def main():
    line = "AMOS Picture Bank (also called AMOS Pac.Pic.) is a raster graphics format associated with AMOS. See AMOS BASIC tokenized file for more information about AMOS. "
    model = "en_US-hfc_male-medium"
    download_dir = "/usr/share/piper-voices/"
    update_voices = False
    # model_path = Path(model)

    # if not model_path.exists():
    # Load voice info
    voices_info = get_voices(download_dir, update_voices=update_voices)
    # ensure_voice_exists(model, [download_dir], download_dir, voices_info)
    file = download_dir + list(voices_info[model]["files"].keys())[0]
    dir = Path(file).parent
    model, config = find_voice(model, [dir])

    speaker = 0

    voice = PiperVoice.load(model, config_path=config, use_cuda=False)
    synthesize_args = {
        "speaker_id": speaker,
        "length_scale": None,
        "noise_scale": None,
        "noise_w": None,
        "sentence_silence": 0.0,
    }

    audio_stream = voice.synthesize_stream_raw(line, **synthesize_args)

    print(audio_stream)

if __name__ == "__main__":
    main()
